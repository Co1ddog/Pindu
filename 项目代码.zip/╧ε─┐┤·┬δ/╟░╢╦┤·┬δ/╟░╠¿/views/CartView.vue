
<script setup>

import Groundincart from "@/components/home/groundincart2.vue";
</script>
<template>

<Groundincart/>
</template>



<style scoped>


</style>