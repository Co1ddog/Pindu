<script setup>
import buyorderinfo from "@/components/orderinfo/Buyorder.vue";
</script>


<template>
  <buyorderinfo/>
</template>

<style scoped>

</style>