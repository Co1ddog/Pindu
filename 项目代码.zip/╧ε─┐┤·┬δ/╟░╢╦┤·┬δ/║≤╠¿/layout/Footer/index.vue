<template>
  <div class="footer-layout">
    <span href="/" target="_blank"> 2022 © VUE-ADMIN-PERFECT By ZB Technology. </span>
  </div>
</template>

<style scoped lang="scss">
  .footer-layout {
    height: 40px;
    font-size: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #ffffff;
    border-top: 1px solid #e4e7ed;
    flex-shrink: 0;
    color: rgba(0, 0, 0, 0.45);
  }
</style>
