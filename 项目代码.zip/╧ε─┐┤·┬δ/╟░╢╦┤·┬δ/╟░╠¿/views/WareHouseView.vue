<template>
<GroundinSale/>
</template>

<script setup>

import GroundinSale from "@/components/home/GroundinSale.vue";
</script>


<style scoped>

</style>