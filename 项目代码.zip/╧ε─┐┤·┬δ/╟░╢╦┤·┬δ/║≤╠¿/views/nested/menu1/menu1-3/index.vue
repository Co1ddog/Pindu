<template>
  <div style="padding: 30px">
    <el-alert title="menu 1-3" type="success" :closable="false" />
  </div>
</template>
