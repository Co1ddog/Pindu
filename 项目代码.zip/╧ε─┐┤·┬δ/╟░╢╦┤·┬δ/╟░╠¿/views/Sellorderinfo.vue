<script setup>
import sellorderinfo from "@/components/orderinfo/sellorder.vue";

</script>


<template>
  <sellorderinfo/>

</template>

<style scoped>

</style>