<template>
  <div style="padding: 30px">
    <el-alert title="menu 1-1" type="success" :closable="false"> </el-alert>
    <router-view />
  </div>
</template>
<script lang="ts" setup name="menu1-1"></script>
