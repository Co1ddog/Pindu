<script setup>
import boughtorderinfo from "@/components/orderinfo/Boughtorder.vue";
</script>


<template>
  <boughtorderinfo/>

</template>

<style scoped>

</style>