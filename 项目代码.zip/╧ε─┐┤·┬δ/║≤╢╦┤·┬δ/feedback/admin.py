from django.contrib import admin

# from feedback.models import Feedback

# Register your models here.
# admin.site.register(Feedback)
