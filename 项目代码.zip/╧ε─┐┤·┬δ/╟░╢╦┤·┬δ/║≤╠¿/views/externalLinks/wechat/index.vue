<template>
  <div class="app-container">
    <div class="app-container-inner">
      <div style="margin-bottom: 20px">欢迎大家加微信哈，共同讨论，学习</div>
      <el-image
        src="http://182.61.5.190:8889/we.png"
        :preview-src-list="['http://182.61.5.190:8889/we.png']"
        style="max-width: 200px"
        :data-resid="Date.now()"
      />
    </div>
  </div>
</template>
