<template>
  <n-grid x-gap="12" :cols="5">
    <n-gi span="2" style="height: 440px">
      <n-carousel v-model:current-index="page" autoplay :show-dots="false">
        <a href="https://book.douban.com/subject/36168920/" target="_blank">
          <div class="text">
            <h1 style="font-weight: bold">寻找自己名字的猫</h1>
            <h5>
              日本绘本4冠王，MOE绘本书店大奖、讲谈社绘本奖、绘本大奖、未来屋绘本大奖。日本亚马逊绘本畅销榜第1名（2021.05）。</h5>
            <p>这只猫让我的心都融化了！
              镇上的猫都有名字，这只猫却没有。
              寺院的猫说：“你可以给自己起名字呀，起一个喜欢的吧。”于是这只猫一边在镇上走，一边寻找自己的名字。
              广告牌、路标、汽车、自行车，“野猫”“走开！”“去！去！”……
              哪个都不能当名字，猫躲在长椅下等待着雨停，心中也充满了雨声。
              忽然传来了一个温柔的声音：“嗨，你肚子饿了吧？”
              听了那个声音，猫意识到自己真正想要的东西，其实是……
              愿世界各地的猫和人类有朝一日能遇见某个人，找到一个安心的地方，幸福地生活下去。</p>
          </div>

        </a>
        <a href="https://book.douban.com/subject/35783446/" target="_blank">
          <div class="text">
            <h1 style="font-weight: bold">创造欧洲人</h1>
            <h5>
              奥兰多·费吉斯（Orlando
              Figes），剑桥大学三一学院博士，现任英国伦敦大学伯贝克学院历史学教授。俄国生活的方方面面，不论是文学艺术，还是政治经济，他都烂熟于心，无人能出其右。他的一系列解读沙俄及苏联历史的著作如《娜塔莎之舞：俄罗斯文化史》《耳语者：斯大林时代苏联的私人生活》《克里米亚战争：被遗忘的帝国博弈》等都取得了非凡的成就，是当今英语世界俄罗斯研究的一流大家。作品曾获沃尔夫森奖、NCR图书奖，并入围萨缪尔·约翰逊奖、达夫·库珀奖等，已被翻译成二十多种文字出版。 </h5>
<!--           -->
            <p>
              1846年6月13日巴黎一布鲁塞尔铁路开通，1500名旅客接受铁路公司经营者罗斯柴尔德男爵的邀请，搭上首航火车。受邀的旅客包括法国国王国王路易·菲利普一世之子内穆尔公爵和蒙庞西耶公爵、法国和比利时的官员们、大仲马、雨果、戈蒂耶、安格尔等名人。旅途中，柏辽兹指挥乐队在火车上演奏了《葬礼及凯旋大交响曲》。这条铁路并非第一条国际铁路，但却被视为最重要的，因为它连接了法国和低地国、英国与德语区。铁路穿越国界，就此开启了欧洲文化的新时代。作家、艺术家、歌剧团、乐队和演员成为常客，搭乘火车穿梭各国，举办大量的演奏会、艺术展览、读书会、沙龙。</p>
          </div>
        </a>
        <a href="https://book.douban.com/subject/36180868/" target="_blank">
          <div class="text">
            <h1 style="font-weight: bold">亨丽埃塔与那场将人类学送上审判席的谋杀案</h1>
            <h5>
              吉尔·施默勒毕业于安默斯特学院和哥伦比亚大学，长期致力于推动非传统的学校教育，以及对以教师为中心的监督模式进行创意探索。此外，他还有一项重要的事业——与他的姐姐伊芙琳一道，研究和讲述他们那位在1931
              年被谋杀的姑姑亨丽埃塔·施默勒的故事。
            </h5>
            <p>
              1930年，年仅22岁的亨丽埃塔·施梅勒被录取为哥伦比亚大学的人类学学生，师从声名显赫的人类学家鲁思·本尼迪克特和弗朗兹·博厄斯。一年后，在他们的提议下，亨丽埃塔满怀期待地独自前往两千多英里外亚利桑那州怀特山区的阿帕奇印第安保留地进行暑期田野调查，不幸遇害。亨丽埃塔的死亡动摇了当时印第安人与白人殖民者之间所建立起的脆弱平衡，也将人类学田野工作方法乃至整个学科置于众人审视的目光之下。本书是主人公的侄子和侄女耗费30年的追寻，其中包括与FBI的一场官司。他们从大量碎片信息中尽力拼凑出一个较为完整的事件脉络，也为亨丽埃塔的死亡去污名化。</p>
          </div>

        </a>
        <a href="https://book.douban.com/subject/36281834/" target="_blank">
          <div class="text">
            <h1 style="font-weight: bold">家族血缘</h1>
            <h5>
              米歇尔·普西（Michel Bussi） 法国悬疑小说家。从2013年开始，他连续7年跻身法国年度畅销作家榜。
              普西擅长以学者的视角深入观察人性的善恶，并进行独特的解读，其作品曲折离奇的情节，让他在法国文坛独树一帜。
              已在中国出版《直到那一天》《她不是我妈妈》《永远不要忘记》《黑色睡莲》等作品。</h5>
            <p>
              这是米歇尔·普西一本精彩的悬疑小说，以莫尔塞岛上两个犯人逃跑开篇，小说讲述了发生在岛上的一个关于宝藏的惊心动魄的故事：两个犯人逃跑后，警方追查，另一方面知晓宝藏秘密的让·雷米的儿子科林重返莫尔塞岛，试图解开父亲去世的谜团。案件交织，线索纠缠到一起，歹徒跨越十年的阴谋浮出水面——在科林继承土地之前得到宝藏。科林被歹徒欺骗并挟持去寻找宝藏，机智的科林一路上给同伴留下线索，在危急时分得救。真相最终揭开，所谓宝藏不过是一款优质葡萄酒和一片土地，但对科林来说，他找到了父亲留下来的满满的爱。小说情节跌宕起伏，双线叙事层层递进，引人入胜，跨越时间和生死的父子亲情极为感动人心，故事对于人性的揭示也让人深思。</p>
          </div>

        </a>
      </n-carousel>
    </n-gi>

    <n-gi span="3" style="height: 440px">
      <n-carousel v-model:current-index="page" autoplay trigger="hover">
        <a href="https://book.douban.com/subject/36168920/" target="_blank">
          <img class="carousel-img" src="../../assets/pictures/sample7.webp" alt="pic">
        </a>
        <a href="https://book.douban.com/subject/35783446/" target="_blank">
          <img class="carousel-img" src="../../assets/pictures/sample8.jpg" alt="pic">
        </a>
        <a href="https://book.douban.com/subject/36180868/" target="_blank">
          <img class="carousel-img" src="../../assets/pictures/sample9.webp" alt="pic">
        </a>
        <a href="https://book.douban.com/subject/36281834/" target="_blank">
          <img class="carousel-img" src="../../assets/pictures/sample4.webp" alt="pic">
        </a>
      </n-carousel>
    </n-gi>
  </n-grid>
</template>

<script setup>
import {ref} from "vue";

const page = ref(0)
</script>

<style scoped>
p {
  margin-top: 10px;
}

.carousel-img {
  width: 100%;
  height: 440px;
  object-fit: cover;
}

.text {
  color: white;
  padding: 30px;
}

a:link {
  text-decoration: none; /* 指正常的未被访问过的链接*/
}

a:visited {
  text-decoration: none; /*指已经访问过的链接*/
}

a:hover {
  text-decoration: none; /*指鼠标在链接*/
}

a:active {
  text-decoration: none; /* 指正在点的链接*/
}

</style>