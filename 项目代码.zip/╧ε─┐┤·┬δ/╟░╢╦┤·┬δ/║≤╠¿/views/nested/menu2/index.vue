<template>
  <div class="app-container">
    <div class="app-container-inner">
      <el-alert title="menu 2" :closable="false" />
    </div>
  </div>
</template>
