<template>
  <div class="app-container">
    <div class="app-container-inner">
      <iframe
        src="https://ext.dcloud.net.cn/plugin?id=7511"
        frameborder="0"
        class="full-iframe"
      ></iframe>
    </div>
  </div>
</template>
<script setup lang="ts" name="embedded"></script>
<style scoped lang="scss">
  .full-iframe {
    width: 100%;
    height: 100%;
  }
</style>
