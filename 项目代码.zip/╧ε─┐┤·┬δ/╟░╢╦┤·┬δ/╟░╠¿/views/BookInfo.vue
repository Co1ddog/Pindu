<script setup>

import book_pic from "@/components/bookinfo/book_pic.vue";




</script>
<template >
  <book_pic />

</template>

<style scoped>

</style>