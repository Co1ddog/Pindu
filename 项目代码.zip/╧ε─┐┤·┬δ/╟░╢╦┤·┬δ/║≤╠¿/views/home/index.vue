<template>
  <div class="app-container">
    <div class="app-container-inner" style="display: flex; align-items: center; justify-content: center; ">
      <img src="./logo.svg" alt="" style="height: 100px">
      <p style="font-weight: bolder; font-size: 80px">品读·后台管理系统</p>
    </div>
  </div>
</template>
<script setup lang="ts">

</script>

<style scoped lang="scss">
@import "./index";
</style>
