<template>
  <div style="height: auto;display: flex;align-items: center;justify-content: center;">
    <book-case/>
  </div>
</template>

<script setup>

import BookCase from "@/components/bookcase/BookCase.vue";
</script>

<style scoped>

</style>