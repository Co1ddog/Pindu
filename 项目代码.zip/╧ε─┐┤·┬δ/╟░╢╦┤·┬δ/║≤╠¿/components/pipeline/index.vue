<template>
  <div class="zb-pipeline">
    <zb-pipeline-start />
  </div>
</template>
<script lang="ts" setup>
  import ZbPipelineStart from './zb-pipeline-start'
</script>
