// * 默认主题颜色
export const PRIMARY_COLOR = '#409eff'
