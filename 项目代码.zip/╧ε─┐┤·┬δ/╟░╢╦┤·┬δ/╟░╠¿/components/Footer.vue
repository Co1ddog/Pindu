<template>
  <div style="background-color: black; height: 115px">
    <n-space align="center" justify="center">

      <n-grid x-gap="0" cols="10" style="width: 100%">


        <n-gi span="2" style="display: flex;align-items: center;justify-content: center;">
          <div style="height: 105px;display: flex;align-items: center;justify-content: center; padding-top: 10px">
            <img src="../assets/logo.png" alt="logo"/>
          </div>
        </n-gi>


        <n-gi span="8" style="display: flex;justify-content: center;align-items: center;">
          <div style="padding-bottom: 5px">
            <div style="width: 100%; display: flex;justify-content: center;align-items: center;">
              <n-button quaternary size="large" style="color: white">品读支持</n-button>
              <n-button quaternary size="large" style="color: white">隐私政策</n-button>
              <n-button quaternary size="large" style="color: white">法规政策</n-button>
            </div>
            <div style="display: flex;justify-content: center;align-items: center;">
              <p style="color: darkgray;width: 100%;height: 50%">品读-C2B2C图书交易平台 | 北京工业大学 经济与管理学院 |
                电话：010-12341234</p>
            </div>
          </div>
        </n-gi>
      </n-grid>
    </n-space>
  </div>
</template>

<script setup>

</script>

<style scoped>

</style>